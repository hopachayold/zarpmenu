﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace PROJEKAT
{
    public partial class Form7 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public Form7()
        {
            InitializeComponent();
            Form5 frm = (Form5)Application.OpenForms["Form5"];
            button1.ForeColor = frm.themecolor2;
            button2.ForeColor = frm.themecolor2;
            label1.ForeColor = frm.themecolor2;
            label2.ForeColor = frm.themecolor2;
            label3.ForeColor = frm.themecolor2;
            if (frm.theme == "green")
            {
                pictureBox3.Image = Properties.Resources.x;
            }
            else if (frm.theme == "bb00bb")
            {
                pictureBox3.Image = Properties.Resources.x_bb00bb;
            }
            panel1.BackColor = ColorTranslator.FromHtml("#111111");
            Form5 forma = (Form5)Application.OpenForms["Form5"];
            this.BackColor = forma.themecolor;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process.Start("NI64.exe");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start("NI.exe");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void label3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}
