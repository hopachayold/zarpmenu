﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace PROJEKAT
{
    public partial class Form5 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public Color themecolor = ColorTranslator.FromHtml("#1A1A1B");
        public Color themecolor2 = ColorTranslator.FromHtml("#90EE90"); //90EE90
        public string theme = "green";
        public Form5()
        {
            InitializeComponent();
            
            label1.ForeColor = themecolor2;
            button1.ForeColor = themecolor2;
            button2.ForeColor = themecolor2;
            button3.ForeColor = themecolor2;
            button4.ForeColor = themecolor2;
            button5.ForeColor = themecolor2;
            button6.ForeColor = themecolor2;
            button7.ForeColor = themecolor2;
            button8.ForeColor = themecolor2;
            button9.ForeColor = themecolor2;
            button10.ForeColor = themecolor2;
            try
            {
                WebClient webclient = new WebClient();
                if(!webclient.DownloadString("https://pastebin.com/raw/2FyNL0nR").Contains("1.2"))
                {
                    if(MessageBox.Show("There is a new version available, do you want to download it?", "Zarp Menu", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        System.Diagnostics.Process.Start("https://github.com/hopachayold/zarpmenu/");
                    }
                }
            }
            catch
            {

            }
            button1.BringToFront();
            this.BackColor = themecolor;
            panel1.BackColor = ColorTranslator.FromHtml("#111111");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 forma = new Form1();
            forma.ShowDialog();
        }
        private void Form5_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.zarpgaming.com");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.steamcommunity.com/id/codabro");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form6 forma = new Form6();
            forma.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form7 forma = new Form7();
            forma.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form4 forma = new Form4();
            forma.ShowDialog();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form8 forma = new Form8();
            forma.ShowDialog();
        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form4 forma = new Form4();
            forma.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://pastebin.com/raw/xftNbm99");
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form9 frma = new Form9();
            frma.ShowDialog();
        }
    }
}
