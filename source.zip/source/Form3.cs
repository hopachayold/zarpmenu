﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJEKAT
{
    public partial class Form3 : Form
    {
        private List<Form1.Printer> printersOutput;
        private string path;
        private Form1 f;
        public Form3(string path, Form1 f)
        {
            InitializeComponent();
            Form5 forma = (Form5)Application.OpenForms["Form5"];
            this.BackColor = forma.themecolor;
            this.path = path;
            string[] files = Directory.GetFiles(path, "*.zarp");
            this.f = f;
            foreach (string file in files)
            {
                string[] words = file.Split('\\');
                string name = words[words.Length - 1].Split('.')[0];
                listBox1.Items.Add(name);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = path + listBox1.SelectedItem + ".zarp";
            FileStream stream = new FileStream(filename, FileMode.Open);
            BinaryReader reader = new BinaryReader(stream);
            printersOutput = (List<Form1.Printer>)ByteArrayToObject(reader.ReadBytes(100000));
            stream.Close();
            f.selectedPrinters = printersOutput;
            f.LIST2.Items.Clear();
            foreach (Form1.Printer printer in f.selectedPrinters)
            {
                f.LIST2.Items.Add(printer.getName() + " x" + printer.getBoostString());
            }
            
            this.Dispose();
        }

        public static object ByteArrayToObject(byte[] arrBytes)
        {
            using (var memStream = new MemoryStream())
            {
                var binForm = new BinaryFormatter();
                memStream.Write(arrBytes, 0, arrBytes.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = binForm.Deserialize(memStream);
                return obj;
            }
        }
    }
}
