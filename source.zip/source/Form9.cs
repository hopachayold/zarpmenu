﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using Newtonsoft.Json;

namespace PROJEKAT
{
    public partial class Form9 : Form
    {
        string baseURL = "http://fastdl.friendlyplayers.com/siggen/darkrpbase/";
        string apiURL = "https://api.steamid.uk/convert.php?api=API_KEY_HERE_GET_UR_OWN";
        public string[] GetSteamID(string input)
        {
            WebClient wc = new WebClient();
            dynamic j = JsonConvert.DeserializeObject(wc.DownloadString(apiURL + $"&input={input}&format=json"));
            string[] ids = { j.converted.steamid, j.converted.steamid64 };
            return ids;
        }

        public void SetInfo(string SteamID64)
        {
            pictureBox1.ImageLocation = baseURL + SteamID64 + ".png";
        }
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public Form9()
        {
            InitializeComponent();
            Form5 frm = (Form5)Application.OpenForms["Form5"];
            this.BackColor = ColorTranslator.FromHtml("#1A1A1B");
            panel2.BackColor = ColorTranslator.FromHtml("#111111");
            textBox1.BackColor = ColorTranslator.FromHtml("#111111");
            textBox1.ForeColor = frm.themecolor2;
            label4.ForeColor = frm.themecolor2;
            label1.ForeColor = frm.themecolor2;
            button2.ForeColor = frm.themecolor2;
            if (frm.theme == "green")
            {
                pictureBox3.Image = Properties.Resources.x;
            }
            else if(frm.theme == "bb00bb")
            {
                pictureBox3.Image = Properties.Resources.x_bb00bb;
            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void label4_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.ToString().Contains("STEAM_"))
                {
                    string SteamID64 = GetSteamID(textBox1.ToString())[1];
                    SetInfo(SteamID64);
                }
                else if (textBox1.ToString().StartsWith("http"))
                {
                    string steam64string = textBox1.Text;
                    string Steam64;

                    if (steam64string.StartsWith("http:")) { Steam64 = steam64string.Replace("http://steamcommunity.com/profiles/", ""); }
                    else { Steam64 = steam64string.Replace("https://steamcommunity.com/profiles/", ""); }


                    SetInfo(Steam64);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Make sure the input was a valid steamid\nprofile link");
                return;
            }
        }
    }
}
