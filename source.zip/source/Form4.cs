﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJEKAT
{
    public partial class Form4 : Form
    {
        int themechoice;
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public Form4()
        {
            InitializeComponent();
            panel3.BackColor = ColorTranslator.FromHtml("#111111");
            Form5 forma = (Form5)Application.OpenForms["Form5"];
            button2.ForeColor = forma.themecolor2;
            label1.ForeColor = forma.themecolor2;
            label2.ForeColor = forma.themecolor2;
            if (forma.theme == "green")
            {
                pictureBox4.Image = Properties.Resources.x;
            }
            else if (forma.theme == "bb00bb")
            {
                pictureBox4.Image = Properties.Resources.x_bb00bb;
            }
            this.BackColor = forma.themecolor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            themechoice = 0;
            panel2.Visible = false;
            panel1.Visible = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            themechoice = 1;
            panel2.Visible = true;
            panel1.Visible = false;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form5 frm = (Form5)Application.OpenForms["Form5"];
            Color boja = Color.Red;
            if(themechoice == 1)
            {
                boja = ColorTranslator.FromHtml("#bb00bb");
                frm.pictureBox1.Image = Properties.Resources.bb00bblogo;
                frm.pictureBox2.Image = Properties.Resources.minimize_bb00bb;
                frm.pictureBox3.Image = Properties.Resources.x_bb00bb;
                frm.theme = "bb00bb";
            }
            else if (themechoice == 0)
            {
                boja = ColorTranslator.FromHtml("#90EE90");
                frm.pictureBox1.Image = Image.FromFile("2018-Full.png");
                frm.pictureBox2.Image = Image.FromFile("minimize.png");
                frm.pictureBox3.Image = Image.FromFile("xx.png");
                frm.theme = "green";
            }
            frm.themecolor2 = boja;
            frm.button1.ForeColor = boja;
            frm.button2.ForeColor = boja;
            frm.button3.ForeColor = boja;
            frm.button4.ForeColor = boja;
            frm.button5.ForeColor = boja;
            frm.button6.ForeColor = boja;
            frm.button7.ForeColor = boja;
            frm.button9.ForeColor = boja;
            frm.button10.ForeColor = boja;
            frm.label1.ForeColor = boja;
            
            this.Dispose();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void panel3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}