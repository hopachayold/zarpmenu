﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJEKAT
{
    public partial class Form1 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        private List<Printer> printers;
        public List<Printer> selectedPrinters;
        private string path;
        public Form1()
        {
            InitializeComponent();
            Form5 frm = (Form5)Application.OpenForms["Form5"];
            button1.ForeColor = frm.themecolor2;
            button2.ForeColor = frm.themecolor2;
            button3.ForeColor = frm.themecolor2;
            button4.ForeColor = frm.themecolor2;
            button5.ForeColor = frm.themecolor2;
            label1.ForeColor = frm.themecolor2;
            label2.ForeColor = frm.themecolor2;
            label3.ForeColor = frm.themecolor2;
            LIST1.ForeColor = frm.themecolor2;
            LIST2.ForeColor = frm.themecolor2;
            radioButton1.ForeColor = frm.themecolor2;
            radioButton2.ForeColor = frm.themecolor2;
            radioButton3.ForeColor = frm.themecolor2;
            radioButton4.ForeColor = frm.themecolor2;
            radioButton5.ForeColor = frm.themecolor2;
            if (frm.theme == "green")
            {
                pictureBox1.Image = Properties.Resources.x;
            }
            else if (frm.theme == "bb00bb")
            {
                pictureBox1.Image = Properties.Resources.x_bb00bb;
            }
            panel1.BackColor = ColorTranslator.FromHtml("#111111");
            LIST1.BackColor = ColorTranslator.FromHtml("#161616");
            LIST2.BackColor = ColorTranslator.FromHtml("#161616");
            Form5 forma = (Form5)Application.OpenForms["Form5"];
            this.BackColor = forma.themecolor;
            path = AppDomain.CurrentDomain.BaseDirectory + "\\combinations\\";
            printers = new List<Printer>();
            selectedPrinters = new List<Printer>();
            printers.Add(new Printer(18000, 1, "Topaz Printer"));
            printers.Add(new Printer(27000, 1, "Amethyst Printer"));
            printers.Add(new Printer(45000, 1, "Emerald Printer"));
            printers.Add(new Printer(135000, 1, "Sapphire Printer"));
            printers.Add(new Printer(36000, 1, "Normal Printer"));
            printers.Add(new Printer(72000, 1, "Ruby Printer"));
            printers.Add(new Printer(144000, 1, "Gold Printer"));
            printers.Add(new Printer(324000, 1, "Nuclear Printer"));
            printers.Add(new Printer(720000, 1, "Diamond Printer"));
            printers.Add(new Printer(1200000, 1, "Black Diamond Printer"));
            printers.Add(new Printer(1800000, 1, "Gencorp Printer"));
            printers.Add(new Printer(1800000, 1, "Festive Printer"));
            printers.Add(new Printer(2250000, 1, "Iridium Printer"));
            printers.Add(new Printer(2400000, 1, "Magik Printer"));
            printers.Add(new Printer(2700000, 1, "Golden Plated Printer"));
            printers.Add(new Printer(2700000, 1, "Ice Printer"));
            printers.Add(new Printer(2700000, 1, "Skull Printer"));
            printers.Add(new Printer(2772000, 1, "XMAS Printer"));
            printers.Add(new Printer(2880000, 1, "Summer Printer"));
            printers.Add(new Printer(2889000, 1, "Hell Printer"));
            printers.Add(new Printer(2520000, 1, "Santa Printer"));
            foreach (Printer printer in printers)
            {
                LIST1.Items.Add(printer.getName());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        [Serializable]
        public class Printer
        {
            private int rate;
            private int boost;
            private string name;
            public Printer()
            {
                this.rate = 0;
                this.boost = 1;
                this.name = "Default printer";            }
            public Printer(int rate, int boost, string name)
            {
                this.rate = rate;
                this.boost = boost;
                this.name = name;
            }
            public Printer(Printer from, int boost)
            {
                this.rate = from.rate;
                this.boost = boost;
                this.name = from.name;
            }
            public string getName()
            {
                return name;
            }
            public int getRate()
            {
                return rate;
            }
            public int getBoost()
            {
                return boost;
            }
            public string getBoostString()
            {
                return boost.ToString();
            }
                public void setBoost(int newBoost)
            {
                boost = newBoost;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int boostSelected = 0;
            if (radioButton1.Checked) boostSelected = 1;
            if (radioButton2.Checked) boostSelected = 2;
            if (radioButton3.Checked) boostSelected = 3;
            if (radioButton4.Checked) boostSelected = 4;
            if (radioButton5.Checked) boostSelected = 5;
            try
            {
                selectedPrinters.Add(new Printer(printers.ElementAt(LIST1.SelectedIndex), boostSelected));
                LIST2.Items.Add(selectedPrinters.Last().getName() + " x" + selectedPrinters.Last().getBoostString());
                button3.Enabled = true;
            }
            catch(Exception)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                selectedPrinters.Remove(selectedPrinters.ElementAt(LIST2.SelectedIndex));
                int sel = LIST2.SelectedIndex;
                if (sel == LIST2.Items.Count - 1)
                    sel--;
                LIST2.Items.RemoveAt(LIST2.SelectedIndex);
                if (LIST2.Items.Count == 0) button3.Enabled = false;
                LIST2.SetSelected(sel,true);
            }
            catch (Exception)
            {

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int totalrate = 0;
            foreach (Printer printer in selectedPrinters)
            {
                totalrate += printer.getRate() * printer.getBoost(); 
            }
            string x = totalrate.ToString("n0");
            MessageBox.Show("$" + x, "Hourly Rate");
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form2 forma = new Form2(selectedPrinters, path);
            forma.ShowDialog();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Form3 forma = new Form3(path, this);
            forma.ShowDialog();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form4 forma = new Form4();
            forma.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Made by Huperchild.", "Info");
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void label3_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}
