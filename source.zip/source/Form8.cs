﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJEKAT
{

    public partial class Form8 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public bool holster = false;
        string[] numpad = { "home", "pgup", "del", "end", "pgdn", "kp_end", "kp_downarrow", "kp_pgdn", "kp_leftarrow", "kp_5", "kp_rightarrow", "kp_home", "kp_up", "kp_pgup" };
        string[] Keys = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","0","1","2","3","4","5","6","7","8","9", "Home", "Page Up", "Delete", "End", "Page Down", "Num1", "Num2", "Num3", "Num4", "Num5", "Num6", "Num7", "Num8", "Num9" };
        string[] Weapons = { "Acid Grenade ", "Advanced Trip Mines ", "Airstrike ", "Base Shield ", "Battle Axe ", "C4 ", "Crafting Hammer ", "De-Animator ", "Defibrillator ", "Diamond Keypad Cracker ", "Diamond Lockpick ", "Diamond Pickaxe ", "Door Charge ", "EMP Grenade ", "Flamethrower ", "Flash Grenade ", "Frag Grenade ", "Gamma Rifle ", "Gauss Rifle ", "GenCorp Orange Core Grenade ", "GenCorp S.C.A.N Master 5000 ", "GenCorp Spartan Laser ", "Gluon Gun ", "Golden GenCorp S.C.A.N Master 5000 ", "Golden Gluon Gun ", "HandCannon ", "Handheld Ion Cannon ", "Iridium Pickaxe ", "Jet Gun ", "K398 ", "Keypad Cracker ", "Knife ", "Laser Dagger ", "Lockpick ", "M134 Minigun ", "M202 RL ", "M303 RL ", "Magik Laser Pistol ", "Matador ", "Medi Shield ", "Minigun 2.0 ", "Molotov Coctail ", "Nerve Gas ", "Ninja Stars ", "Nitro Glycerine ", "Orbital Strike ", "PSG-1 ", "Pickaxe ", "Portable EMP ", "Printer Booster ", "Printer Booster x3 ", "Printer Booster x4 ", "Printer Hacker 2 ", "Printer Hacker ", "Proximity Mine ", "RPG-7 ", "Radiation Shiled ", "Riot Shield ", "SLAM ", "Smoke Grenade ", "Tactical Insertion ", "Thermal Detonator ", "Thunder Hammer ", "Thundergun (T-Gun) " };
        string[] WepBinds = {"mm_acidflask", "weapon_advancedtripmine", "airstrike", "weapon_baseshield5000", "mm_battleaxe", "m9k_suicide_bomb", "hammer", "mm_deanimator", "weapon_defib", "diamondcracker", "diamondlockpick", "pickaxediamond", "m9k_doorcharge", "m9k_emp_grenade", "mm_flamethrower", "weapon_real_cs_flash", "weapon_real_cs_grenade", "weapon_gammashooter", "weapon_gauss_rifle", "m9k_orangecore_grenade", "weapon_scanmaster5000", "weapon_spartanlaser", "weapon_gluongun", "weapon_scanmaster5000_golden", "weapon_gluongun_golden", "weapon_hand_cannon", "weapon_ioncannon", "pickaxeiridium", "weapon_jetgun", "weapon_k398", "cracker", "m9k_knife", "m9k_laserdagger", "lockpick", "m9k_minigun", "m9k_m202", "m9k_m303", "weapon_laserpistol2", "m9k_matador", "weapon_medishield", "weapon_minigun2", "molotov_cocktail", "m9k_nerve_gas", "weapon_ninjastars", "m9k_nitro", "m9k_orbital_strike", "m9k_psg1", "pickaxe", "weapon_portableemp", "printer_booster", "printer_boostertriple", "printer_boosterquad", "weapon_printerhacker2", "weapon_printerhacker", "m9k_proxy_mine", "m9k_rpg7", "weapon_radiationshield", "riot_shield", "weapon_slam", "weapon_real_cs_smoke", "weapon_tacticalinsertion", "weapon_detonator", "weapon_thunderhammer", "weapon_hoff_thundergun"};
        string[] Suits = {"Advanced Combat Suit", "Nano Suit", "Hyper Suit", "Juggernaut Suit", "Golden Juggernaut Suit", "Visor Suit", "Holo Suit", "Portal Suit", "Mummy Suit", "EDF Suit", "Golden Nano Suit", "Golden ACS"};
        string[] SuitBinds = { "advanced combat suit", "nano suit", "hyper suit", "gencorp juggernaut suit", "golden juggernaut suit", "visor suit", "holo pilot suit", "portal suit", "mummy suit", "edf police heavy armor suit", "golden nano suit", "golden advanced combat suit" };
        string[] PoliceBinds = { "say /me Weapon Check! Restisting = AOS/KOS", "zarp_equipitem edf police heavy armor suit", "say /votecp", "say /voteprisonguard", "say /voteswat", "say /fbi", "say /security", "say /votesasmember" };
        string[] StaffBinds = { "say /teleport", "say /backspawn", "say /tptopos -1966,-5721,121", "say /tptopos -274,-2361,60", "say /back", "noclip", "say /cloak", "say /uncloak" };
        string[] TTTBinds = { "ttt_radio imwith", "ttt_radio suspect", "ttt_radio traitor", "ttt_radio innocent", "ttt_radio see", "ttt_radio check", "ulx noclip", "ulx fspec @", "ulx bring @", "xgui" };
        public Form8()
        {
            InitializeComponent();
            panel2.BackColor = ColorTranslator.FromHtml("#111111");
            textBox2.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox1.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox2.BackColor = ColorTranslator.FromHtml("#111111");
            textBox1.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox4.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox3.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox5.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox6.BackColor = ColorTranslator.FromHtml("#111111");
            textBox3.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox7.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox8.BackColor = ColorTranslator.FromHtml("#111111");
            textBox4.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox9.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox10.BackColor = ColorTranslator.FromHtml("#111111");
            textBox5.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox11.BackColor = ColorTranslator.FromHtml("#111111");
            comboBox12.BackColor = ColorTranslator.FromHtml("#111111");
            textBox6.BackColor = ColorTranslator.FromHtml("#111111");
            this.BackColor = ColorTranslator.FromHtml("#1A1A1B");
            Form5 frm = (Form5)Application.OpenForms["Form5"];
            button1.ForeColor = frm.themecolor2;
            button2.ForeColor = frm.themecolor2;
            button3.ForeColor = frm.themecolor2;
            button4.ForeColor = frm.themecolor2;
            button5.ForeColor = frm.themecolor2;
            button6.ForeColor = frm.themecolor2;
            button7.ForeColor = frm.themecolor2;
            button8.ForeColor = frm.themecolor2;
            button9.ForeColor = frm.themecolor2;
            button10.ForeColor = frm.themecolor2;
            button11.ForeColor = frm.themecolor2;
            button12.ForeColor = frm.themecolor2;
            button13.ForeColor = frm.themecolor2;
            button14.ForeColor = frm.themecolor2;
            button15.ForeColor = frm.themecolor2;
            button16.ForeColor = frm.themecolor2;
            button17.ForeColor = frm.themecolor2;
            button18.ForeColor = frm.themecolor2;
            button19.ForeColor = frm.themecolor2;
            label1.ForeColor = frm.themecolor2;
            label2.ForeColor = frm.themecolor2;
            label3.ForeColor = frm.themecolor2;
            label4.ForeColor = frm.themecolor2;
            label5.ForeColor = frm.themecolor2;
            label6.ForeColor = frm.themecolor2;
            label7.ForeColor = frm.themecolor2;
            label8.ForeColor = frm.themecolor2;
            label9.ForeColor = frm.themecolor2;
            label10.ForeColor = frm.themecolor2;
            label11.ForeColor = frm.themecolor2;
            label12.ForeColor = frm.themecolor2;
            label13.ForeColor = frm.themecolor2;
            label14.ForeColor = frm.themecolor2;
            label15.ForeColor = frm.themecolor2;
            label16.ForeColor = frm.themecolor2;
            label17.ForeColor = frm.themecolor2;
            label18.ForeColor = frm.themecolor2;
            label19.ForeColor = frm.themecolor2;
            label20.ForeColor = frm.themecolor2;
            comboBox1.ForeColor = frm.themecolor2;
            comboBox2.ForeColor = frm.themecolor2;
            comboBox3.ForeColor = frm.themecolor2;
            comboBox4.ForeColor = frm.themecolor2;
            comboBox5.ForeColor = frm.themecolor2;
            comboBox6.ForeColor = frm.themecolor2;
            comboBox7.ForeColor = frm.themecolor2;
            comboBox8.ForeColor = frm.themecolor2;
            comboBox9.ForeColor = frm.themecolor2;
            comboBox10.ForeColor = frm.themecolor2;
            comboBox11.ForeColor = frm.themecolor2;
            comboBox12.ForeColor = frm.themecolor2;
            textBox1.ForeColor = frm.themecolor2;
            textBox2.ForeColor = frm.themecolor2;
            textBox3.ForeColor = frm.themecolor2;
            textBox4.ForeColor = frm.themecolor2;
            textBox5.ForeColor = frm.themecolor2;
            textBox6.ForeColor = frm.themecolor2;
            checkBox1.ForeColor = frm.themecolor2;
            if (frm.theme == "green")
            {
                pictureBox3.Image = Properties.Resources.x;
            }
            else if (frm.theme == "bb00bb")
            {
                pictureBox3.Image = Properties.Resources.x_bb00bb;
            }

            for (int i = 0; i < Weapons.Length; i++)
            {
                comboBox1.Items.Add(Weapons[i]);
            }
            for (int i = 0; i < Keys.Length; i++)
            {
                comboBox2.Items.Add(Keys[i]);
                comboBox3.Items.Add(Keys[i]);
                comboBox7.Items.Add(Keys[i]);
                comboBox9.Items.Add(Keys[i]);
                comboBox11.Items.Add(Keys[i]);
            }
            for (int i = 0; i < Suits.Length; i++)
            {
                comboBox4.Items.Add(Suits[i]);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label1.Focus();
        }

        private void comboBox1_DropDownClosed(object sender, EventArgs e)
        {
            label1.Focus();
        }

        private void comboBox2_DropDownClosed(object sender, EventArgs e)
        {
            label1.Focus();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex < 36 & !string.IsNullOrEmpty(comboBox2.Text) & !string.IsNullOrEmpty(comboBox1.Text))
            {
                if(holster == true)
                {
                    string bind = "bind " + comboBox2.Text + " \"zarp_equipitem " + WepBinds[comboBox1.SelectedIndex] + "; say /holster" + "\"";
                    textBox2.Text = bind;
                }
                else
                {
                    string bind = "bind " + comboBox2.Text + " \"zarp_equipitem " + WepBinds[comboBox1.SelectedIndex] + "\"";
                    textBox2.Text = bind;
                }
            }
            else if (!(comboBox2.SelectedIndex < 36) & !string.IsNullOrEmpty(comboBox2.Text) & !string.IsNullOrEmpty(comboBox1.Text))
            {
                if(holster == true)
                {
                    string bind = "bind " + numpad[comboBox2.SelectedIndex - 36] + " \"zarp_equipitem " + WepBinds[comboBox1.SelectedIndex] + "; say /holster" + "\"";
                    textBox2.Text = bind;
                }
                else
                {
                    string bind = "bind " + numpad[comboBox2.SelectedIndex-36] + " \"zarp_equipitem " + WepBinds[comboBox1.SelectedIndex] + "\"";
                    textBox2.Text = bind;
                }
                
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBox2.Text);
            }
            catch
            {

            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = false;
            panel1.Visible = true;
            panel5.Visible = false;
            panel7.Visible = false;
            panel6.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            panel3.Visible = true;
            panel4.Visible = false;
            panel7.Visible = false;
            panel6.Visible = false;
            panel1.Visible = false;
            panel5.Visible = false;
        }

        private void comboBox3_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void comboBox4_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex < 36 & !string.IsNullOrEmpty(comboBox3.Text) & !string.IsNullOrEmpty(comboBox4.Text))
            {
                string bind = "bind " + comboBox3.Text + " \"zarp_equipitem " + SuitBinds[comboBox4.SelectedIndex] + "\"";
                textBox1.Text = bind;
            }
            else if (!(comboBox3.SelectedIndex < 36) & !string.IsNullOrEmpty(comboBox3.Text) & !string.IsNullOrEmpty(comboBox4.Text))
            {
                string bind = "bind " + numpad[comboBox3.SelectedIndex - 36] + " \"zarp_equipitem " + SuitBinds[comboBox4.SelectedIndex] + "\"";
                textBox1.Text = bind;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBox1.Text);
            }
            catch
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            panel3.Visible = false;
            panel4.Visible = true;
            panel1.Visible = false;
            panel5.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
        }

        private void comboBox6_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void comboBox5_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            string bind = "bind mouse1 \"_inven gems " + comboBox5.Text + " " + (comboBox6.SelectedIndex + 1) + "; +attack\"";
            textBox3.Text = bind;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBox3.Text);
            }
            catch
            {

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel5.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
            panel1.Visible = false;
            panel6.Visible = false;
            panel7.Visible = false;
        }

        private void comboBox7_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void comboBox8_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (comboBox7.SelectedIndex < 36 & !string.IsNullOrEmpty(comboBox7.Text) & !string.IsNullOrEmpty(comboBox8.Text))
            {
                string bind = "bind " + comboBox7.Text + " \"" + PoliceBinds[comboBox8.SelectedIndex] + "\"";
                textBox4.Text = bind;
            }
            else if (!(comboBox7.SelectedIndex < 36) & !string.IsNullOrEmpty(comboBox7.Text) & !string.IsNullOrEmpty(comboBox8.Text))
            {
                string bind = "bind " + numpad[comboBox7.SelectedIndex - 36] + " \"" + PoliceBinds[comboBox8.SelectedIndex] + "\"";
                textBox4.Text = bind;
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBox4.Text);
            }
            catch
            {

            }
        }

        private void comboBox9_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void comboBox10_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel1.Visible = false;
            panel7.Visible = false;
            panel6.Visible = true;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            if (comboBox9.SelectedIndex < 36 & !string.IsNullOrEmpty(comboBox9.Text) & !string.IsNullOrEmpty(comboBox10.Text))
            {
                string bind = "bind " + comboBox9.Text + " \"" + StaffBinds[comboBox10.SelectedIndex] + "\"";
                textBox5.Text = bind;
            }
            else if (!(comboBox9.SelectedIndex < 36) & !string.IsNullOrEmpty(comboBox9.Text) & !string.IsNullOrEmpty(comboBox10.Text))
            {
                string bind = "bind " + numpad[comboBox9.SelectedIndex - 36] + " \"" + StaffBinds[comboBox10.SelectedIndex] + "\"";
                textBox5.Text = bind;
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBox5.Text);
            }
            catch
            {

            }
        }

        private void comboBox11_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void comboBox12_DropDownClosed(object sender, EventArgs e)
        {
            label4.Focus();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            panel5.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
            panel1.Visible = false;
            panel6.Visible = false;
            panel7.Visible = true;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (comboBox11.SelectedIndex < 36 & !string.IsNullOrEmpty(comboBox11.Text) & !string.IsNullOrEmpty(comboBox12.Text))
            {
                string bind = "bind " + comboBox11.Text + " \"" + TTTBinds[comboBox12.SelectedIndex] + "\"";
                textBox6.Text = bind;
            }
            else if (!(comboBox11.SelectedIndex < 36) & !string.IsNullOrEmpty(comboBox11.Text) & !string.IsNullOrEmpty(comboBox12.Text))
            {
                string bind = "bind " + numpad[comboBox11.SelectedIndex - 36] + " \"" + TTTBinds[comboBox12.SelectedIndex] + "\"";
                textBox6.Text = bind;
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(textBox6.Text);
            }
            catch
            {

            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void label4_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if(holster == true)
            {
                holster = false;
            }
            else
            {
                holster = true;
            }
        }
    }
}
