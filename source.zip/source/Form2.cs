﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJEKAT
{
    public partial class Form2 : Form
    {
        private List<Form1.Printer> printersToSave;
        private string path;
        public Form2(List<Form1.Printer> printers, string path)
        {
            InitializeComponent();
            this.printersToSave = printers;
            this.path = path;
            Form5 forma = (Form5)Application.OpenForms["Form5"];
            this.BackColor = forma.themecolor;
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        public static byte[] ObjectToByteArray(Object obj)
        {
            BinaryFormatter bf = new BinaryFormatter();
            using (var ms = new MemoryStream())
            {
                bf.Serialize(ms, obj);
                return ms.ToArray();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            string filename = textBox1.Text + ".zarp";
            FileStream stream = new FileStream(path + filename, FileMode.OpenOrCreate);
            BinaryWriter writer = new BinaryWriter(stream);
            writer.Write(ObjectToByteArray(printersToSave));
            stream.Close();
            this.Dispose();
        }
    }
}
