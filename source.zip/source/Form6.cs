﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROJEKAT
{
    public partial class Form6 : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();
        public Form6()
        {

            InitializeComponent();
            Form5 frm = (Form5)Application.OpenForms["Form5"];
            button1.ForeColor = frm.themecolor2;
            button2.ForeColor = frm.themecolor2;
            button3.ForeColor = frm.themecolor2;
            button4.ForeColor = frm.themecolor2;
            button5.ForeColor = frm.themecolor2;
            button6.ForeColor = frm.themecolor2;
            button7.ForeColor = frm.themecolor2;
            button8.ForeColor = frm.themecolor2;
            button9.ForeColor = frm.themecolor2;
            button10.ForeColor = frm.themecolor2;
            button11.ForeColor = frm.themecolor2;
            label1.ForeColor = frm.themecolor2;
            label2.ForeColor = frm.themecolor2;
            label3.ForeColor = frm.themecolor2;
            label4.ForeColor = frm.themecolor2;
            label5.ForeColor = frm.themecolor2;
            label6.ForeColor = frm.themecolor2;
            label7.ForeColor = frm.themecolor2;
            label8.ForeColor = frm.themecolor2;
            label9.ForeColor = frm.themecolor2;
            if (frm.theme == "green")
            {
                pictureBox3.Image = Properties.Resources.x;
            }
            else if (frm.theme == "bb00bb")
            {
                pictureBox3.Image = Properties.Resources.x_bb00bb;
            }
            panel1.BackColor = ColorTranslator.FromHtml("#111111");
            button1.BringToFront();
            Form5 forma = (Form5)Application.OpenForms["Form5"];
            this.BackColor = forma.themecolor;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("steam://connect/darkrp.zarpgaming.com:27015");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("steam://connect/usa.zarpgaming.com:27015");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("steam://connect/play.zarpgaming.com:27035");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("steam://connect/play.zarpgaming.com:27019");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("steam://connect/play.zarpgaming.com:27030");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("steam://connect/play.zarpgaming.com:27040");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("ts3server://ts.zarpgaming.com:9987/");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("steam://connect/play.zarpgaming.com:27017");
        }
        private void button8_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://discordapp.com/invite/AYeSSeb");
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void label9_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}
